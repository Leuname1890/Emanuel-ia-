# Emanuel AI — código-fonte inicial para Android

Este pacote contém o código-fonte Flutter do Emanuel AI. Ele inclui a interface Android, navegação e um chat que se conecta à API Gemini. As abas Imagens, Vídeos, Músicas e Programação já têm telas-base, mas ainda precisam receber as integrações de geração.

> **Importante:** este pacote contém o código Dart e as dependências. A pasta Android nativa é gerada pelo Flutter no primeiro setup, seguindo os passos abaixo.

## O que já funciona

- Interface escura chamada Emanuel AI.
- Navegação entre Chat, Imagens, Vídeos, Músicas e Código.
- Chat conectado à API Gemini, depois de configurar uma chave.
- Configuração da chave e do modelo dentro do aplicativo.

## O que ainda será desenvolvido

A geração real de imagens, vídeos e músicas, agentes autônomos, login, sincronização na nuvem e publicação em lojas ainda não estão integrados. O projeto não promete acesso gratuito ilimitado a modelos comerciais. Vamos usar cotas gratuitas e modelos abertos quando disponíveis.

## 1. Instalar as ferramentas

Você precisará de um computador Windows, macOS ou Linux.

1. Instale o Flutter: https://docs.flutter.dev/get-started/install
2. Instale o Android Studio: https://developer.android.com/studio
3. No Android Studio, instale Android SDK e Android SDK Command-line Tools.
4. Abra o terminal e execute:

```bash
flutter doctor
```

Siga as correções indicadas até o Flutter reconhecer o Android toolchain.

## 2. Preparar o projeto Android

1. Extraia este ZIP.
2. Abra o terminal dentro da pasta `emanuel_ai`.
3. Gere os arquivos nativos do Android:

```bash
flutter create --platforms=android --org com.emanuelai .
```

4. Confirme que `lib/main.dart` continua sendo o arquivo deste pacote. Se o Flutter tiver substituído o arquivo, copie novamente `lib/main.dart` deste pacote para a pasta `lib` do projeto.
5. Substitua o `pubspec.yaml` pelo arquivo deste pacote.
6. Execute:

```bash
flutter pub get
flutter run
```

Conecte um celular Android com Depuração USB ativada ou inicie um emulador.

## 3. Criar uma chave Gemini gratuita

1. Acesse https://aistudio.google.com/app/apikey
2. Entre na sua conta Google e crie uma chave de API.
3. Abra Emanuel AI no celular.
4. Toque na engrenagem, cole a chave e salve.
5. Volte ao Chat e envie uma pergunta.

A modalidade gratuita tem limites que podem variar por modelo, região e política do provedor. Consulte https://ai.google.dev/gemini-api/docs/pricing.

## 4. Gerar o APK

No terminal, dentro da pasta do projeto:

```bash
flutter build apk --release
```

O APK será criado em:

```text
build/app/outputs/flutter-apk/app-release.apk
```

Para gerar APKs menores por arquitetura:

```bash
flutter build apk --split-per-abi
```

## 5. Instalar no Android

Transfira `app-release.apk` para o celular, abra o arquivo e autorize a instalação de aplicativos dessa origem, se o Android solicitar.

## Segurança — leia antes de compartilhar

Esta primeira versão guarda a chave localmente no aparelho para facilitar testes pessoais. Isso não é adequado para distribuir publicamente: uma chave dentro de um aplicativo pode ser extraída. Para publicar para outras pessoas, crie um backend que mantenha a chave no servidor, aplique limites por usuário e nunca exponha segredos no APK.

## Próximas etapas

1. Testar o chat Gemini.
2. Criar backend seguro e contas de usuário.
3. Integrar geração de imagens com uma opção gratuita.
4. Integrar geração de vídeo e áudio, respeitando as cotas dos provedores.
5. Adicionar histórico, favoritos e exportação.
6. Testar em aparelhos Android e preparar publicação.
