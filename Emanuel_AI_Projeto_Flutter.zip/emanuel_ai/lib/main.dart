import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const EmanuelAiApp());
}

const Color bg = Color(0xFF0B0D14);
const Color panel = Color(0xFF171A26);
const Color purple = Color(0xFF9B7BFF);

class EmanuelAiApp extends StatelessWidget {
  const EmanuelAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Emanuel AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: purple,
          brightness: Brightness.dark,
          surface: panel,
        ),
        useMaterial3: true,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: panel,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selected = 0;
  final pages = const [
    ChatPage(),
    ToolPage(
      title: 'Imagens',
      icon: Icons.image_outlined,
      description: 'Prepare prompts e conecte um serviço de geração de imagens.',
      details: 'A próxima etapa será integrar um gerador com plano gratuito ou modelo aberto. Cada serviço possui seus próprios limites.',
    ),
    ToolPage(
      title: 'Vídeos',
      icon: Icons.movie_creation_outlined,
      description: 'Central para criação de vídeos com inteligência artificial.',
      details: 'A geração de vídeo costuma exigir bastante processamento. Vamos priorizar serviços com cota grátis e deixar claro quando houver limites.',
    ),
    ToolPage(
      title: 'Músicas',
      icon: Icons.music_note_outlined,
      description: 'Espaço para criação de músicas e trilhas com IA.',
      details: 'A integração será feita com ferramentas que permitam uso gratuito. Não vamos prometer geração ilimitada.',
    ),
    ToolPage(
      title: 'Programação',
      icon: Icons.code,
      description: 'Peça ajuda para criar sites, aplicativos e códigos.',
      details: 'Você já pode usar a aba Chat para pedir códigos. Depois adicionaremos editor, projetos e exportação.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: bg,
        titleSpacing: 20,
        title: const Row(
          children: [
            Icon(Icons.auto_awesome, color: purple),
            SizedBox(width: 9),
            Text('Emanuel AI', style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Configurações',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => showDialog(
              context: context,
              builder: (_) => const SettingsDialog(),
            ),
          ),
        ],
      ),
      body: IndexedStack(index: selected, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selected,
        onDestinationSelected: (i) => setState(() => selected = i),
        backgroundColor: panel,
        indicatorColor: purple.withOpacity(.22),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Chat'),
          NavigationDestination(icon: Icon(Icons.image_outlined), label: 'Imagens'),
          NavigationDestination(icon: Icon(Icons.movie_outlined), label: 'Vídeos'),
          NavigationDestination(icon: Icon(Icons.music_note_outlined), label: 'Músicas'),
          NavigationDestination(icon: Icon(Icons.code), label: 'Código'),
        ],
      ),
    );
  }
}

class ChatMessage {
  final String text;
  final bool isUser;
  ChatMessage(this.text, this.isUser);
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final input = TextEditingController();
  final scroll = ScrollController();
  final messages = <ChatMessage>[
    ChatMessage('Olá! Eu sou o Emanuel AI. Configure sua chave de API nas configurações para conversar com a IA.', false),
  ];
  bool sending = false;

  Future<void> send() async {
    final prompt = input.text.trim();
    if (prompt.isEmpty || sending) return;
    input.clear();
    setState(() {
      messages.add(ChatMessage(prompt, true));
      sending = true;
    });
    _scrollDown();

    try {
      final prefs = await SharedPreferences.getInstance();
      final apiKey = prefs.getString('gemini_api_key') ?? '';
      final model = prefs.getString('gemini_model') ?? 'gemini-2.5-flash';
      if (apiKey.isEmpty) {
        setState(() => messages.add(ChatMessage(
          'Antes de conversar, abra Configurações e adicione sua chave gratuita do Google AI Studio. Veja o passo a passo no arquivo README do projeto.',
          false,
        )));
      } else {
        final uri = Uri.parse(
          'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey',
        );
        final history = messages
            .where((m) => m.text != messages.first.text)
            .toList();
        final contents = history.map((m) => {
          'role': m.isUser ? 'user' : 'model',
          'parts': [{'text': m.text}],
        }).toList();

        final response = await http.post(
          uri,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'contents': contents}),
        ).timeout(const Duration(seconds: 45));

        final data = jsonDecode(response.body);
        if (response.statusCode >= 200 && response.statusCode < 300) {
          final answer = data['candidates']?[0]?['content']?['parts']?[0]?['text']
              ?.toString() ?? 'A IA não retornou texto.';
          setState(() => messages.add(ChatMessage(answer, false)));
        } else {
          final error = data['error']?['message']?.toString() ?? response.body;
          setState(() => messages.add(ChatMessage('Erro da API: $error', false)));
        }
      }
    } catch (e) {
      setState(() => messages.add(ChatMessage('Não foi possível conectar. Verifique a internet e sua chave de API. Detalhe: $e', false)));
    } finally {
      setState(() => sending = false);
      _scrollDown();
    }
  }

  void _scrollDown() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) {
        scroll.animateTo(scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            controller: scroll,
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
            itemCount: messages.length,
            itemBuilder: (context, i) {
              final m = messages[i];
              return Align(
                alignment: m.isUser ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 330),
                  margin: const EdgeInsets.symmetric(vertical: 7),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: m.isUser ? const Color(0xFF493A78) : panel,
                    borderRadius: BorderRadius.circular(17),
                  ),
                  child: Text(m.text, style: const TextStyle(fontSize: 15, height: 1.4)),
                ),
              );
            },
          ),
        ),
        if (sending)
          const Padding(
            padding: EdgeInsets.only(bottom: 8),
            child: LinearProgressIndicator(minHeight: 2),
          ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: input,
                    minLines: 1,
                    maxLines: 5,
                    onSubmitted: (_) => send(),
                    decoration: const InputDecoration(
                      hintText: 'Pergunte qualquer coisa...',
                      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  style: IconButton.styleFrom(backgroundColor: purple),
                  onPressed: sending ? null : send,
                  icon: const Icon(Icons.send, color: Colors.white),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class ToolPage extends StatelessWidget {
  final String title;
  final IconData icon;
  final String description;
  final String details;

  const ToolPage({
    super.key,
    required this.title,
    required this.icon,
    required this.description,
    required this.details,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const SizedBox(height: 20),
        CircleAvatar(
          radius: 36,
          backgroundColor: purple.withOpacity(.18),
          child: Icon(icon, size: 36, color: purple),
        ),
        const SizedBox(height: 20),
        Text(title, textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Text(description, textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white70, fontSize: 16)),
        const SizedBox(height: 25),
        Card(
          color: panel,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(children: [
                  Icon(Icons.construction, color: purple),
                  SizedBox(width: 8),
                  Text('Área em desenvolvimento', style: TextStyle(fontWeight: FontWeight.bold)),
                ]),
                const SizedBox(height: 12),
                Text(details, style: const TextStyle(height: 1.5, color: Colors.white70)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Text(
          'O projeto começa com o chat conectado. As outras ferramentas serão adicionadas por etapas, usando integrações gratuitas sempre que possível.',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white38, fontSize: 12),
        ),
      ],
    );
  }
}

class SettingsDialog extends StatefulWidget {
  const SettingsDialog({super.key});

  @override
  State<SettingsDialog> createState() => _SettingsDialogState();
}

class _SettingsDialogState extends State<SettingsDialog> {
  final keyController = TextEditingController();
  final modelController = TextEditingController(text: 'gemini-2.5-flash');
  bool obscure = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    keyController.text = prefs.getString('gemini_api_key') ?? '';
    modelController.text = prefs.getString('gemini_model') ?? 'gemini-2.5-flash';
    if (mounted) setState(() {});
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('gemini_api_key', keyController.text.trim());
    await prefs.setString('gemini_model',
        modelController.text.trim().isEmpty ? 'gemini-2.5-flash' : modelController.text.trim());
    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Configurações salvas neste aparelho.')),
      );
    }
  }

  @override
  void dispose() {
    keyController.dispose();
    modelController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Configurar Emanuel AI'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Adicione sua chave da API Gemini. A modalidade gratuita tem limites e pode mudar conforme a região e as regras do Google.'),
            const SizedBox(height: 14),
            TextField(
              controller: keyController,
              obscureText: obscure,
              decoration: InputDecoration(
                labelText: 'Chave da API',
                suffixIcon: IconButton(
                  icon: Icon(obscure ? Icons.visibility : Icons.visibility_off),
                  onPressed: () => setState(() => obscure = !obscure),
                ),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: modelController,
              decoration: const InputDecoration(labelText: 'Modelo Gemini'),
            ),
            const SizedBox(height: 10),
            const Text('Importante: esta versão é para uso pessoal/testes. Não publique o APK com sua chave dentro. Um app público precisa de um servidor intermediário para proteger as chaves.', style: TextStyle(fontSize: 12, color: Colors.orangeAccent)),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
        FilledButton(onPressed: _save, child: const Text('Salvar')),
      ],
    );
  }
}
